import json
import requests

url = "http://35.230.78.123"

def lambda_handler(event, context):
    # TODO implement
    print(event)
    session_id = event["sessionId"]
    data = {
        "session_id": session_id,
        "input": event["inputTranscript"]
    }
    response = requests.post(url, json=data)
    return {
        "sessionState": {
            "dialogAction": {
                "type": "ElicitIntent"
            },
            "intent": {
                "name": "FallbackIntent",
                "state": "Fulfilled"
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": "you said, " + event["inputTranscript"]
            }
        ]
    }